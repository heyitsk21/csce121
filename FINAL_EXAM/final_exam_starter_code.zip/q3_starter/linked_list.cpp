#include <stdexcept>
#include "linked_list.h"

int LinkedList::at(size_t) const {
  // TODO(student): return the value at the index
  return 0;
}

void LinkedList::insert(size_t, int) {
  // TODO(student): insert the value at the index
}

void LinkedList::merge(const LinkedList&) {
  // TODO(student): merge the other list into this list
}
